    import { Component } from '@angular/core';
    import { mobiscroll, MbscCalendarOptions, MbscFormOptions } from '../lib/mobiscroll/js/mobiscroll.angular.min.js';
    
    mobiscroll.settings = {
        lang: 'en',             // Specify language like: lang: 'pl' or omit setting to use default
        theme: 'ios',           // Specify theme like: theme: 'ios' or omit setting to use default
        themeVariant: 'light'   // More info about themeVariant: https://docs.mobiscroll.com/4-10-9/angular/select#opt-themeVariant
    };
    
    @Component({
        selector: 'app-root',
        templateUrl: './app.component.html'
    })
    export class AppComponent {
        names = [{
                text: 'Abigail Hodges',
                value: 1
            }
        ];
        
        myData = {
            url: 'https://trial.mobiscroll.com/airports/',
            remoteFilter: true,
            dataType: 'jsonp',
            processResponse: function (data) {
                const ret = [];
    
                if (data) {
                    for (let i = 0; i < data.length; i++) {
                        const item = data[i];
                        ret.push({
                            value: item.code,
                            text: item.name,
                            html: '<div style="font-size:16px;line-height:18px;">' + item.name +
                                '</div><div style="font-size:10px;line-height:12px;">' + item.location + ', ' + item.code + '</div>'
                        });
                    }
                }
    
                return ret;
            }
        };
    
        localSettings = {
            display: 'center',  // Specify display mode like: display: 'bottom' or omit setting to use default
            filter: true        // More info about filter: https://docs.mobiscroll.com/4-10-9/angular/select#opt-filter
        };
    
        remoteSettings = {
            display: 'center',  // Specify display mode like: display: 'bottom' or omit setting to use default
            multiline: 2,       // More info about multiline: https://docs.mobiscroll.com/4-10-9/angular/select#opt-multiline
            height: 50,         // More info about height: https://docs.mobiscroll.com/4-10-9/angular/select#opt-height
            data: this.myData,  // More info about data: https://docs.mobiscroll.com/4-10-9/angular/select#opt-data
            filter: true        // More info about filter: https://docs.mobiscroll.com/4-10-9/angular/select#opt-filter
        };
    }
