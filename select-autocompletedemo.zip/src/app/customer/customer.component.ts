import { Component, OnInit } from '@angular/core';
import { MyserviceService, Customers } from '../myservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  message: string;
  customers: Customers[];
  constructor(private myservice: MyserviceService, private router: Router) { }

  ngOnInit(): any  {
    this.myservice.getCustomers().subscribe(
      response => this.handleSuccessfulResponse(response),
    );
  }
  handleSuccessfulResponse(response) {
    this.customers = response;
  }
  update(updatecustomer: Customers) {
    this.myservice.update(updatecustomer);
    this.router.navigate(['/updatecust']); 
  }
}
