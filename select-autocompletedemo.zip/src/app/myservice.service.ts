import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
  updatecustomer: Customers;
  constructor(private httpService: HttpClient) { }
  public getCustomers() {
    console.log("ins service get customers");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.get<Customers>(" http://localhost:8586/profile/createProfile");
  } 
  public update(updatecustomer: Customers) {
    this.updatecustomer = updatecustomer;
  }
  public updateMethod() {
    return this.updatecustomer;
  }
  public onUpdate(updatecustomer: Customers) {
    console.log("ins service update");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.put(" http://localhost:8586/profile/customers/{id}", updatecustomer,  { headers, responseType: 'text'});
  }
}
export class Customers {
  id: number;
  name: string;
  email: string;
}